package com.springdemo;

public interface Coach {
	public String getDailyWorkout();

}
